#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -f .env ] || { cp .env.example .env; echo "สร้าง .env แล้ว กรุณาใส่ DISCORD_TOKEN ก่อน"; exit 1; }
npm start
