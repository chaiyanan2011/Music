@echo off
chcp 65001 >nul
cd /d %~dp0
if not exist .env (
  copy .env.example .env >nul
  echo สร้าง .env แล้ว กรุณาใส่ DISCORD_TOKEN ก่อน
  pause
  exit /b 1
)
call npm start
pause
