@echo off
chcp 65001 >nul
cd /d %~dp0
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] ไม่พบ Node.js กรุณาติดตั้ง Node.js 22.12 ขึ้นไป
  pause
  exit /b 1
)
if not exist .env copy .env.example .env >nul
echo ติดตั้งแพ็กเกจและ yt-dlp...
call npm install
if errorlevel 1 (
  echo [ERROR] npm install ไม่สำเร็จ
  pause
  exit /b 1
)
echo.
echo เสร็จแล้ว เปิดไฟล์ .env และใส่ DISCORD_TOKEN จากนั้นดับเบิลคลิก start.bat
pause
