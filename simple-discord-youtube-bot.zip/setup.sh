#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "ต้องติดตั้ง Node.js 22.12+ ก่อน"; exit 1; }
[ -f .env ] || cp .env.example .env
npm install
echo "เสร็จแล้ว: แก้ .env ใส่ DISCORD_TOKEN แล้วรัน ./start.sh"
