const fs = require('node:fs');
const path = require('node:path');
const { pipeline } = require('node:stream/promises');
const { Readable } = require('node:stream');

const force = process.argv.includes('--force');
const ROOT = path.join(__dirname, '..');
const BIN_DIR = path.join(ROOT, 'bin');

function assetForPlatform() {
  if (process.platform === 'win32') {
    if (process.arch === 'arm64') return { asset: 'yt-dlp_arm64.exe', file: 'yt-dlp.exe' };
    if (process.arch === 'ia32') return { asset: 'yt-dlp_x86.exe', file: 'yt-dlp.exe' };
    return { asset: 'yt-dlp.exe', file: 'yt-dlp.exe' };
  }

  if (process.platform === 'darwin') {
    return { asset: 'yt-dlp_macos', file: 'yt-dlp_macos' };
  }

  if (process.platform === 'linux') {
    if (process.arch === 'arm64') return { asset: 'yt-dlp_linux_aarch64', file: 'yt-dlp' };
    if (process.arch === 'x64') return { asset: 'yt-dlp_linux', file: 'yt-dlp' };
    throw new Error(`Linux architecture ${process.arch} ยังไม่รองรับอัตโนมัติ กรุณาติดตั้ง yt-dlp เอง`);
  }

  throw new Error(`ระบบปฏิบัติการ ${process.platform} ยังไม่รองรับ`);
}

async function main() {
  fs.mkdirSync(BIN_DIR, { recursive: true });
  const { asset, file } = assetForPlatform();
  const target = path.join(BIN_DIR, file);

  if (!force && fs.existsSync(target) && fs.statSync(target).size > 1_000_000) {
    console.log(`[yt-dlp] มีไฟล์อยู่แล้ว: ${target}`);
    return;
  }

  const url = `https://github.com/yt-dlp/yt-dlp/releases/latest/download/${asset}`;
  console.log(`[yt-dlp] ดาวน์โหลด ${url}`);
  const response = await fetch(url, { redirect: 'follow' });
  if (!response.ok || !response.body) {
    throw new Error(`ดาวน์โหลด yt-dlp ไม่สำเร็จ HTTP ${response.status}`);
  }

  const temp = `${target}.download`;
  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(temp));
  fs.renameSync(temp, target);
  if (process.platform !== 'win32') fs.chmodSync(target, 0o755);
  console.log(`[yt-dlp] พร้อมใช้งาน: ${target}`);
}

main().catch((error) => {
  console.error('[yt-dlp] ERROR:', error.message);
  process.exit(1);
});
