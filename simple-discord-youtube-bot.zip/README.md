# Simple Discord YouTube Music Bot

บอทเพลง Discord แบบง่าย: **สมาชิกอยู่ในห้องเสียงแล้ววางลิงก์ YouTube ในแชตได้เลย** บอทจะเข้าห้องเสียง อัปเดตคิว และเล่นต่อทีละเพลงโดยอัตโนมัติ

## ความสามารถ

- วางลิงก์ `youtube.com`, `youtu.be`, YouTube Shorts หรือ Live ได้โดยไม่ต้องพิมพ์ `/play`
- บอทเข้าห้องเสียงของผู้ส่งลิงก์ให้อัตโนมัติ
- คิวเพลงแยกแต่ละเซิร์ฟเวอร์
- แจ้งชื่อเพลง ช่อง YouTube ระยะเวลา และ **ใครเป็นคนขอเพลง**
- `!queue` ดูคิว
- `!now` ดูเพลงปัจจุบัน
- `!skip` ข้ามเพลง
- `!stop` หยุดและล้างคิว
- `!leave` ให้ออกจากห้องเสียง
- `!volume 0-100` ตั้งความดังถาวรของแต่ละเซิร์ฟเวอร์ — ใช้ได้เฉพาะ Administrator หรือผู้มี Manage Server
- เมื่อคิวหมดจะออกจากห้องอัตโนมัติ (ค่าเริ่มต้น 120 วินาที)

## สิ่งที่ต้องมี

- Node.js **22.12.0 ขึ้นไป**
- อินเทอร์เน็ตสำหรับดาวน์โหลดแพ็กเกจและ yt-dlp ครั้งแรก
- Discord Bot Token

`npm install` จะดาวน์โหลด `yt-dlp` ล่าสุดลงโฟลเดอร์ `bin/` ให้อัตโนมัติ และ `ffmpeg-static` จะติดตั้ง FFmpeg ให้ผ่าน npm

## ตั้งค่า Discord Bot

1. เข้า Discord Developer Portal > Applications > New Application
2. เมนู **Bot** > สร้าง Bot และคัดลอก Token
3. ในหน้า Bot เปิด **MESSAGE CONTENT INTENT** เพราะระบบต้องอ่านข้อความเพื่อจับลิงก์ YouTube
4. เมนู OAuth2 > URL Generator
5. Scopes เลือก `bot`
6. Bot Permissions อย่างน้อย:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
   - Connect
   - Speak
7. เปิดลิงก์ที่ Discord สร้างให้แล้วเชิญบอทเข้าเซิร์ฟเวอร์

> อย่าแชร์ Bot Token ให้ผู้อื่น และอย่าอัปโหลดไฟล์ `.env` ขึ้น GitHub

## ติดตั้งแบบ Windows

1. แตก ZIP
2. ดับเบิลคลิก `setup.bat`
3. เปิด `.env` แล้วใส่ Token:

```env
DISCORD_TOKEN=ใส่_token_ตรงนี้
IDLE_LEAVE_SECONDS=120
DEFAULT_VOLUME=35
```

4. ดับเบิลคลิก `start.bat`

## Linux / VPS

```bash
chmod +x setup.sh start.sh
./setup.sh
nano .env
./start.sh
```

สำหรับใช้งานจริงบน VPS แนะนำรันผ่าน PM2 หรือ systemd เพื่อให้บอทเปิดตลอดเวลา

## วิธีใช้

1. เข้า Voice Channel
2. ส่งลิงก์ เช่น `https://youtu.be/...` ในห้องข้อความ
3. บอทจะเข้าห้องและเล่นให้ทันที ถ้ามีเพลงกำลังเล่นอยู่จะต่อคิว

ตัวอย่างตั้งเสียงโดยผู้ดูแล:

```text
!volume 25
```

เสียงจะถูกบันทึกใน `data/settings.json` และใช้ต่อไปแม้รีสตาร์ตบอท

## ถ้า YouTube เล่นไม่ได้

YouTube เปลี่ยนระบบบ่อย ให้ปิดบอทแล้วรัน:

```bash
npm run update-ytdlp
```

จากนั้นเปิดบอทใหม่

## หมายเหตุ

ใช้บอทกับเนื้อหาที่คุณมีสิทธิ์เข้าถึงและใช้งาน และปฏิบัติตามข้อกำหนดของ Discord/YouTube
