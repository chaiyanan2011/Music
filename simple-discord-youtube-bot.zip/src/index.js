const {
  Client,
  GatewayIntentBits,
  PermissionsBitField,
  EmbedBuilder
} = require('discord.js');
const { SettingsStore, clampVolume } = require('./settings');
const { MusicManager } = require('./musicManager');
const { findYouTubeUrl, getVideoInfo, formatDuration } = require('./youtube');

const token = process.env.DISCORD_TOKEN;
if (!token || token === 'PUT_YOUR_BOT_TOKEN_HERE') {
  console.error('❌ กรุณาสร้างไฟล์ .env แล้วใส่ DISCORD_TOKEN ก่อน');
  process.exit(1);
}

const defaultVolume = clampVolume(process.env.DEFAULT_VOLUME) ?? 35;
const idleLeaveSeconds = Math.max(10, Number(process.env.IDLE_LEAVE_SECONDS) || 120);
const settings = new SettingsStore(defaultVolume);
const music = new MusicManager({ settings, idleLeaveSeconds });

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates
  ]
});

client.once('ready', () => {
  console.log(`✅ Online: ${client.user.tag}`);
  console.log(`🔊 Default volume: ${defaultVolume}% | idle leave: ${idleLeaveSeconds}s`);
  client.user.setActivity('วางลิงก์ YouTube เพื่อเปิดเพลง');
});

client.on('messageCreate', async (message) => {
  if (!message.guild || message.author.bot) return;
  const content = message.content.trim();
  const state = music.get(message.guild);

  if (/^!help\b/i.test(content)) {
    const embed = new EmbedBuilder()
      .setTitle('🎶 คำสั่ง Music Bot')
      .setDescription('อยู่ในห้องเสียงแล้ว **วางลิงก์ YouTube ในแชตได้เลย** บอทจะเข้าห้องและต่อคิวให้อัตโนมัติ')
      .addFields(
        { name: '!queue', value: 'ดูคิวเพลง' },
        { name: '!now', value: 'ดูเพลงที่กำลังเล่น' },
        { name: '!skip', value: 'ข้ามเพลงปัจจุบัน' },
        { name: '!stop', value: 'หยุดและล้างคิว' },
        { name: '!leave', value: 'ให้บอทออกจากห้องเสียง' },
        { name: '!volume 0-100', value: 'ตั้งความดัง (ผู้ดูแลเซิร์ฟเวอร์เท่านั้น)' }
      );
    return message.reply({ embeds: [embed] });
  }

  if (/^!volume\b/i.test(content)) {
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator)
      || message.member.permissions.has(PermissionsBitField.Flags.ManageGuild);
    if (!isAdmin) return message.reply('⛔ คำสั่งนี้ใช้ได้เฉพาะผู้ดูแลเซิร์ฟเวอร์');

    const value = clampVolume(content.split(/\s+/)[1]);
    if (value === null) return message.reply(`🔊 ระดับเสียงปัจจุบัน **${state.volume}%**\nใช้: \`!volume 0-100\``);

    const saved = state.setVolume(value);
    return message.reply(`✅ ตั้งระดับเสียงของเซิร์ฟเวอร์เป็น **${saved}%** แล้ว`);
  }

  if (/^!queue\b/i.test(content)) {
    const lines = [];
    if (state.current) lines.push(`▶️ **กำลังเล่น:** [${state.current.title}](${state.current.url}) — <@${state.current.requesterId}>`);
    state.queue.slice(0, 10).forEach((track, i) => {
      lines.push(`${i + 1}. [${track.title}](${track.url}) — <@${track.requesterId}>`);
    });
    if (!lines.length) return message.reply('📭 ตอนนี้ไม่มีเพลงในคิว');
    if (state.queue.length > 10) lines.push(`…และอีก ${state.queue.length - 10} เพลง`);
    return message.reply({
      embeds: [new EmbedBuilder().setTitle('📋 คิวเพลง').setDescription(lines.join('\n')).setFooter({ text: `เสียง ${state.volume}%` })]
    });
  }

  if (/^!now\b/i.test(content)) {
    if (!state.current) return message.reply('⏹️ ตอนนี้ยังไม่มีเพลงกำลังเล่น');
    const t = state.current;
    return message.reply(`🎵 **${t.title}** • ${t.channel} • ${formatDuration(t.duration)} • ขอโดย <@${t.requesterId}>`);
  }

  if (/^!skip\b/i.test(content)) {
    if (!isSameVoiceChannel(message, state)) return;
    return message.reply(state.skip() ? '⏭️ ข้ามเพลงแล้ว' : '📭 ไม่มีเพลงให้ข้าม');
  }

  if (/^!stop\b/i.test(content)) {
    if (!isSameVoiceChannel(message, state)) return;
    state.stop();
    return message.reply('⏹️ หยุดเพลงและล้างคิวแล้ว');
  }

  if (/^!leave\b/i.test(content)) {
    if (!isSameVoiceChannel(message, state)) return;
    state.leave();
    return message.reply('👋 ออกจากห้องเสียงแล้ว');
  }

  const youtubeUrl = findYouTubeUrl(content);
  if (!youtubeUrl) return;

  const voiceChannel = message.member.voice.channel;
  if (!voiceChannel) {
    return message.reply('🎧 เข้าห้องเสียงก่อน แล้ววางลิงก์ YouTube อีกครั้ง');
  }

  const status = await message.reply('🔎 กำลังอ่านข้อมูลเพลงจาก YouTube…');

  try {
    const info = await getVideoInfo(youtubeUrl);
    const track = {
      ...info,
      requesterId: message.author.id,
      requesterName: message.member.displayName
    };

    await state.enqueue(track, voiceChannel, message.channel);
    const position = state.current === track ? 0 : state.queue.findIndex((x) => x === track) + 1;

    const embed = new EmbedBuilder()
      .setTitle(position === 0 ? '▶️ เริ่มเล่นแล้ว' : '✅ เพิ่มเข้าคิวแล้ว')
      .setDescription(`[${track.title}](${track.url})`)
      .addFields(
        { name: 'ช่อง', value: track.channel, inline: true },
        { name: 'ความยาว', value: formatDuration(track.duration), inline: true },
        { name: 'ขอโดย', value: `<@${message.author.id}>`, inline: true },
        { name: 'ตำแหน่งคิว', value: position === 0 ? 'กำลังเล่น' : `#${position}`, inline: true },
        { name: 'ระดับเสียง', value: `${state.volume}%`, inline: true }
      );
    if (track.thumbnail?.startsWith('http')) embed.setThumbnail(track.thumbnail);

    await status.edit({ content: '', embeds: [embed] });
  } catch (error) {
    console.error(error);
    if (String(error.message).startsWith('BUSY:')) {
      const channelId = error.message.split(':')[1];
      return status.edit(`🎧 บอทกำลังเล่นอยู่ใน <#${channelId}> กรุณาเข้าห้องนั้นก่อน`);
    }
    return status.edit(`❌ เพิ่มเพลงไม่สำเร็จ: ${humanizeError(error)}`);
  }
});

function isSameVoiceChannel(message, state) {
  const userChannel = message.member.voice.channel;
  if (!userChannel) {
    message.reply('🎧 คุณต้องอยู่ในห้องเสียงก่อน').catch(() => {});
    return false;
  }
  const botChannelId = state.connection?.joinConfig?.channelId;
  if (botChannelId && botChannelId !== userChannel.id) {
    message.reply(`🎧 กรุณาอยู่ห้องเดียวกับบอท <#${botChannelId}>`).catch(() => {});
    return false;
  }
  return true;
}

function humanizeError(error) {
  const text = String(error?.message || error);
  if (/Sign in to confirm|bot|cookies/i.test(text)) {
    return 'YouTube ปฏิเสธการดึงสตรีมชั่วคราว ลองอัปเดต yt-dlp ด้วย `npm run update-ytdlp`';
  }
  if (/timeout/i.test(text)) return 'เชื่อมต่อ YouTube นานเกินไป ลองใหม่อีกครั้ง';
  return text.slice(0, 250);
}

process.on('unhandledRejection', (error) => console.error('Unhandled rejection:', error));
process.on('uncaughtException', (error) => console.error('Uncaught exception:', error));

client.login(token);
