const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

function clampVolume(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return Math.max(0, Math.min(100, Math.round(n)));
}

class SettingsStore {
  constructor(defaultVolume = 35) {
    this.defaultVolume = clampVolume(defaultVolume) ?? 35;
    this.data = {};
    this.load();
  }

  load() {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    try {
      if (!fs.existsSync(SETTINGS_FILE)) {
        fs.writeFileSync(SETTINGS_FILE, '{}\n', 'utf8');
        return;
      }
      const parsed = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
      this.data = parsed && typeof parsed === 'object' ? parsed : {};
    } catch (error) {
      console.error('[settings] อ่าน settings.json ไม่สำเร็จ:', error.message);
      this.data = {};
    }
  }

  save() {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const temp = `${SETTINGS_FILE}.tmp`;
    fs.writeFileSync(temp, `${JSON.stringify(this.data, null, 2)}\n`, 'utf8');
    fs.renameSync(temp, SETTINGS_FILE);
  }

  getVolume(guildId) {
    const saved = clampVolume(this.data[guildId]?.volume);
    return saved ?? this.defaultVolume;
  }

  setVolume(guildId, volume) {
    const normalized = clampVolume(volume);
    if (normalized === null) throw new Error('Invalid volume');
    this.data[guildId] ??= {};
    this.data[guildId].volume = normalized;
    this.save();
    return normalized;
  }
}

module.exports = { SettingsStore, clampVolume };
