const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  NoSubscriberBehavior,
  VoiceConnectionStatus,
  entersState
} = require('@discordjs/voice');
const { EmbedBuilder } = require('discord.js');
const { getAudioStreamUrl, formatDuration } = require('./youtube');

class GuildMusicState {
  constructor({ guild, settings, idleLeaveSeconds }) {
    this.guild = guild;
    this.settings = settings;
    this.idleLeaveSeconds = idleLeaveSeconds;
    this.queue = [];
    this.current = null;
    this.connection = null;
    this.player = createAudioPlayer({
      behaviors: { noSubscriber: NoSubscriberBehavior.Pause }
    });
    this.textChannel = null;
    this.idleTimer = null;
    this.playLock = false;

    this.player.on(AudioPlayerStatus.Idle, () => {
      if (this.current) this.current = null;
      this.playNext().catch((error) => this.handlePlaybackError(error));
    });

    this.player.on('error', (error) => {
      this.handlePlaybackError(error);
    });
  }

  get volume() {
    return this.settings.getVolume(this.guild.id);
  }

  isActive() {
    return Boolean(this.current || this.queue.length);
  }

  async ensureConnection(voiceChannel) {
    clearTimeout(this.idleTimer);
    this.idleTimer = null;

    if (this.connection && this.connection.joinConfig.channelId !== voiceChannel.id) {
      if (this.isActive()) {
        throw new Error(`BUSY:${this.connection.joinConfig.channelId}`);
      }
      this.connection.destroy();
      this.connection = null;
    }

    if (!this.connection || this.connection.state.status === VoiceConnectionStatus.Destroyed) {
      this.connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: voiceChannel.guild.id,
        adapterCreator: voiceChannel.guild.voiceAdapterCreator,
        selfDeaf: true,
        selfMute: false
      });

      this.connection.on(VoiceConnectionStatus.Disconnected, async () => {
        try {
          await Promise.race([
            entersState(this.connection, VoiceConnectionStatus.Signalling, 5_000),
            entersState(this.connection, VoiceConnectionStatus.Connecting, 5_000)
          ]);
        } catch {
          try { this.connection.destroy(); } catch {}
          this.connection = null;
        }
      });

      this.connection.subscribe(this.player);
    }

    await entersState(this.connection, VoiceConnectionStatus.Ready, 20_000);
  }

  async enqueue(track, voiceChannel, textChannel) {
    await this.ensureConnection(voiceChannel);
    this.textChannel = textChannel;
    this.queue.push(track);

    if (!this.current && this.player.state.status === AudioPlayerStatus.Idle) {
      await this.playNext();
    }
  }

  async playNext() {
    if (this.playLock || this.current) return;
    const track = this.queue.shift();
    if (!track) {
      this.scheduleLeave();
      return;
    }

    this.playLock = true;
    this.current = track;

    try {
      const streamUrl = await getAudioStreamUrl(track.url);
      const resource = createAudioResource(streamUrl, {
        inlineVolume: true,
        metadata: track
      });
      resource.volume.setVolume(this.volume / 100);
      this.player.play(resource);
      await entersState(this.player, AudioPlayerStatus.Playing, 20_000);
      await this.sendNowPlaying(track);
    } catch (error) {
      this.current = null;
      await this.sendError(`เล่น **${track.title}** ไม่สำเร็จ: ${error.message}`);
      setImmediate(() => this.playNext().catch((e) => this.handlePlaybackError(e)));
    } finally {
      this.playLock = false;
    }
  }

  setVolume(percent) {
    const saved = this.settings.setVolume(this.guild.id, percent);
    const resource = this.player.state.resource;
    if (resource?.volume) resource.volume.setVolume(saved / 100);
    return saved;
  }

  skip() {
    if (!this.current) return false;
    this.player.stop(true);
    return true;
  }

  stop() {
    this.queue = [];
    this.current = null;
    this.player.stop(true);
    this.scheduleLeave(2_000);
  }

  leave() {
    clearTimeout(this.idleTimer);
    this.idleTimer = null;
    this.queue = [];
    this.current = null;
    this.player.stop(true);
    if (this.connection) {
      try { this.connection.destroy(); } catch {}
    }
    this.connection = null;
  }

  scheduleLeave(ms = this.idleLeaveSeconds * 1000) {
    clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      if (!this.isActive()) this.leave();
    }, Math.max(1_000, ms));
    this.idleTimer.unref?.();
  }

  async sendNowPlaying(track) {
    if (!this.textChannel?.isTextBased()) return;
    const embed = new EmbedBuilder()
      .setTitle('🎵 กำลังเล่น')
      .setDescription(`[${track.title}](${track.url})`)
      .addFields(
        { name: 'ช่อง', value: track.channel || 'YouTube', inline: true },
        { name: 'ความยาว', value: formatDuration(track.duration), inline: true },
        { name: 'เสียง', value: `${this.volume}%`, inline: true },
        { name: 'ขอโดย', value: `<@${track.requesterId}>`, inline: true },
        { name: 'คิวถัดไป', value: `${this.queue.length} เพลง`, inline: true }
      )
      .setTimestamp();

    if (track.thumbnail?.startsWith('http')) embed.setThumbnail(track.thumbnail);
    await this.textChannel.send({ embeds: [embed] }).catch(() => {});
  }

  async sendError(text) {
    if (!this.textChannel?.isTextBased()) return;
    await this.textChannel.send(`⚠️ ${text}`).catch(() => {});
  }

  async handlePlaybackError(error) {
    console.error(`[music:${this.guild.id}]`, error);
    const failed = this.current;
    this.current = null;
    if (failed) await this.sendError(`เกิดข้อผิดพลาดระหว่างเล่น **${failed.title}** กำลังข้ามไปเพลงถัดไป`);
    if (this.player.state.status !== AudioPlayerStatus.Idle) this.player.stop(true);
    setImmediate(() => this.playNext().catch((e) => console.error(e)));
  }
}

class MusicManager {
  constructor({ settings, idleLeaveSeconds = 120 }) {
    this.settings = settings;
    this.idleLeaveSeconds = idleLeaveSeconds;
    this.states = new Map();
  }

  get(guild) {
    let state = this.states.get(guild.id);
    if (!state) {
      state = new GuildMusicState({
        guild,
        settings: this.settings,
        idleLeaveSeconds: this.idleLeaveSeconds
      });
      this.states.set(guild.id, state);
    }
    return state;
  }
}

module.exports = { MusicManager };
