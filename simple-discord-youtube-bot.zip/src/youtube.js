const path = require('node:path');
const fs = require('node:fs');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');

const execFileAsync = promisify(execFile);
const ROOT = path.join(__dirname, '..');
const YTDLP = process.platform === 'win32'
  ? path.join(ROOT, 'bin', 'yt-dlp.exe')
  : process.platform === 'darwin'
    ? path.join(ROOT, 'bin', 'yt-dlp_macos')
    : path.join(ROOT, 'bin', 'yt-dlp');

function findYouTubeUrl(text) {
  if (!text) return null;
  const candidates = text.match(/https?:\/\/[^\s<>]+/gi) ?? [];

  for (const raw of candidates) {
    const cleaned = raw.replace(/[),.!?\]}>]+$/g, '');
    try {
      const url = new URL(cleaned);
      const host = url.hostname.toLowerCase().replace(/^www\./, '');
      const allowed = new Set([
        'youtube.com',
        'm.youtube.com',
        'music.youtube.com',
        'youtu.be'
      ]);
      if (!allowed.has(host)) continue;

      if (host === 'youtu.be' && url.pathname.length > 1) return url.toString();
      if (url.pathname === '/watch' && url.searchParams.get('v')) return url.toString();
      if (url.pathname.startsWith('/shorts/') || url.pathname.startsWith('/live/')) return url.toString();
    } catch {
      // ไม่ใช่ URL ที่ parse ได้
    }
  }
  return null;
}

async function runYtDlp(args, timeout = 45_000) {
  if (!fs.existsSync(YTDLP)) {
    throw new Error('ไม่พบ yt-dlp กรุณารัน npm install หรือ npm run update-ytdlp');
  }

  const { stdout } = await execFileAsync(YTDLP, args, {
    windowsHide: true,
    timeout,
    maxBuffer: 12 * 1024 * 1024
  });
  return stdout.trim();
}

async function getVideoInfo(url) {
  const out = await runYtDlp([
    '--no-playlist',
    '--dump-single-json',
    '--skip-download',
    '--no-warnings',
    '--no-progress',
    url
  ]);

  const info = JSON.parse(out);
  return {
    id: info.id,
    title: info.title || 'Unknown title',
    channel: info.channel || info.uploader || 'YouTube',
    duration: Number.isFinite(info.duration) ? info.duration : null,
    thumbnail: info.thumbnail || null,
    url: info.webpage_url || url
  };
}

async function getAudioStreamUrl(url) {
  const out = await runYtDlp([
    '--no-playlist',
    '--no-warnings',
    '--no-progress',
    '-f',
    'bestaudio[acodec=opus]/bestaudio/best',
    '-g',
    url
  ], 60_000);

  const lines = out.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  if (!lines.length) throw new Error('yt-dlp ไม่คืน URL เสียง');
  return lines[0];
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return 'ไม่ทราบเวลา';
  const s = Math.floor(seconds % 60).toString().padStart(2, '0');
  const totalMinutes = Math.floor(seconds / 60);
  const m = (totalMinutes % 60).toString().padStart(2, '0');
  const h = Math.floor(totalMinutes / 60);
  return h > 0 ? `${h}:${m}:${s}` : `${totalMinutes}:${s}`;
}

module.exports = {
  findYouTubeUrl,
  getVideoInfo,
  getAudioStreamUrl,
  formatDuration
};
